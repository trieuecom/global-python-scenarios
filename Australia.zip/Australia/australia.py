'''
australia.py

A program that simulates the relocation of Australian animals across states.

Each animal has a known threat to avoid. The goal is to relocate as many 
animals as possible while ensuring that no animal ends up near its threat — 
and no two animals share the same state.

This program involves reading animal data from a file, building objects to
represent each animal, and implementing relocation logic to ensure animals
are placed safely.
'''


ADJACENT_STATES = {
    'NSW': ['VIC', 'SA', 'QLD'],
    'QLD': ['NT', 'SA', 'NSW'],
    'VIC': ['SA', 'NSW'],
    'TAS': [],
    'SA': ['WA', 'NT', 'QLD', 'NSW', 'VIC'],
    'NT': ['WA', 'SA', 'QLD'],
    'WA': ['SA', 'NT']
}  # fill in with adjacent states for each state!


class FictionalAnimal:
    '''
    Represents a fictional Australian animal used in the relocation simulation.

    Each animal has a name, habitat, threat, and current state.
    '''
    def __init__(self, name: str, habitat: str, threat: str):
        '''
        Initialises a new FictionalAnimal with the given name, habitat, and threat.
        Sets the starting state to 'ACT' by default.

        Parameters:
            name (str): The name of the animal.
            habitat (str): The animal's preferred habitat.
            threat (str): The name of another animal that poses a threat.
        '''
        self.name = name
        self.habitat = habitat 
        self.threat = threat
        self.state = 'ACT'


    def get_state(self) -> str:
        '''Returns the current state where this animal is located.'''
        return self.state


    def set_state(self, state: str):
        '''
        Updates the animal's state if the new state is valid.

        A valid state is one that exists in the list of defined states.
        If the state is not valid, the location does not change.

        Parameters:
            state (str): The new state to assign to the animal.
        '''
        if state in ADJACENT_STATES:
            self.state = state
        return None



    def __str__(self) -> str:
        '''
        Returns a formatted string representing the animal's details.
        Format:
        <name>
           Habitat : <habitat>
           Threat  : <threat>
           State   : <state>
        '''
        animal_details = f'''{self.name}
   Habitat : {self.habitat}
   Threat  : {self.threat}
   State   : {self.state}'''
        return animal_details
        


    def load_dataset() -> list['FictionalAnimal']:
        '''
        Loads animal data from animals.csv and returns a list of FictionalAnimal
        objects.

        Lines must follow the format: <name>,<habitat>,<threat>

        Lines with missing or extra fields are skipped.
        If the file does not exist, returns an empty list.

        Returns:
            list[FictionalAnimal]: A list of valid animal objects.
        '''
        fictional_animal = []
        try:
            with open('animals.csv', 'r') as f:
                for line in f:
                    if len(line.split(',')) == 3:
                        split_parts = line.strip().split(',')
                        animal = FictionalAnimal(split_parts[0], split_parts[1], split_parts[2])                   
                        fictional_animal.append(animal)
            return fictional_animal
        except:
            return fictional_animal


def relocate_animals(animals: list[FictionalAnimal]):
    '''
    Simulates the relocation of Australian animals. 
    
    No two animals can share the same state, and no animal can be next to its
    threat.

    The relocation respects the following fixed state order:
    NSW → QLD → VIC → TAS → SA → NT → WA

    Animals are considered for relocation one by one, in the order they appear
    in the list. If an animal cannot be placed in a state, its state remains 
    as 'ACT'.

    Parameters:
        animals (list[FictionalAnimal]): A list of FictionalAnimal objects.
    '''
    animal_occupied_states = {}
    state_order = ['NSW', 'QLD', 'VIC', 'TAS', 'SA', 'NT', 'WA']
    #scan through each state in the state order
    for state in state_order:
        #scan through each animal in each stage
        for animal in animals:
            #only consider animals that are not relocated
            if animal.get_state() == 'ACT':
                #check the state          
                if state in animal_occupied_states:
                    continue

                threat_status = False
                for adjacent_state in ADJACENT_STATES[state]:
                    if adjacent_state in animal_occupied_states and animal_occupied_states[adjacent_state].name == animal.threat:
                        threat_status = True
                        break
                if threat_status:
                    continue


                threat_status_to_neighbor = False
                for adjacent_state in ADJACENT_STATES[state]:
                    if adjacent_state in animal_occupied_states and animal_occupied_states[adjacent_state].threat == animal.name:
                        threat_status_to_neighbor = True
                        break
                if threat_status_to_neighbor:
                    continue

                
                animal.set_state(state)
                animal_occupied_states[state] = animal
                break

def main():
    '''
    Runs the full relocation simulation from start to finish.

    This function should:
    - Load the fictional animal data from animals.txt
    - Print each animal's details before relocation
    - Relocate the animals using relocate_animals()
    - Print each animal's updated details after relocation
    '''
    # bird = FictionalAnimal('bird1', 'water', 'none')
    # print(bird)
    # print(bird.get_state())
    # print(ADJACENT_STATES['NSW'])
    # aus_animals = FictionalAnimal.load_dataset()
    # relocate_animals(aus_animals)

    print(">> READING IN ANIMALS.")
    animals = FictionalAnimal.load_dataset()
    animal_count = len(animals)
    print(f'Loaded {animal_count} animals from animals.csv.')
    print('\n>> BEFORE RELOCATION.')
    for animal in animals:
        print(animal)
        print('')
    print('>> RELOCATING ANIMALS.')
    relocate_animals(animals)

    animal_relocated_count = 0
    for animal in animals:
        if animal.state != 'ACT':
            animal_relocated_count += 1

    print(f'Animals relocated: {animal_relocated_count}/{animal_count}')

    print('\n>> SUMMARY.')
    for animal in animals:
        print(f'{animal.name}: {animal.state}') 



  

# Do not modify this!
if __name__ == '__main__':
    main()
