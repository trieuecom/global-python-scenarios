'''
japan.py

A program that allows a user to reforge an imperfect katana blueprint
to match a master blacksmith's perfect design. The katana is represented
using '#' for the blade, and '=' and '|' for the handle.

The program compares similarity scores, accepts or rejects katanas,
and repeatedly prompts the user to reforge the blade until it meets
the required similarity threshold.

Usage:
    python3 japan.py <imperfect_blueprint.bp> <min_similarity>
'''

import sys
import os

def print_katana(bp: str):
    '''
    Prints the contents of a katana blueprint file.

    Parameters:
        bp (str): The filename of the katana blueprint (.bp file).
    '''
    with open(bp, 'r') as f:
        for line in f:
            print(line, end = '')


def get_similarity_score(imperfect_bp: str) -> float:
    '''
    Compares the blade of an imperfect katana against the perfect katana
    in perfect_katana.bp.

    Calculates and returns a similarity score between 0 and 1, where 1 means
    a perfect match. The similarity is based on the number of '#' symbols
    per line in the blade section only.

    Parameters:
        imperfect_bp (str): The filename of the imperfect katana blueprint.

    Returns:
        float: The average line similarity between the two blueprints.
    '''
    with open('perfect_katana.bp', 'r') as f1:
        perfect_katana_hash_count = []
        for line in f1:
            if line.startswith('='):
                break
            perfect_katana_hash_char = line.count('#')
            perfect_katana_hash_count.append(perfect_katana_hash_char)
            

        # print(perfect_katana_hash_count)        

    with open(imperfect_bp, 'r') as f2:
        imperfect_katana_hash_count = []
        for line in f2:
            if line.startswith('='):
                break
            imperfect_katana_hash_char = line.count('#')
            imperfect_katana_hash_count.append(imperfect_katana_hash_char)
            

        # print(imperfect_katana_hash_count)
    


    line_similarity = []
    for a, b in zip(perfect_katana_hash_count, imperfect_katana_hash_count):
        if a >= b:
            line_similarity_result = b/a
            line_similarity.append(line_similarity_result)
        elif a < b:
            line_similarity_result = a/b
            line_similarity.append(line_similarity_result)
    
    blade_line = len(line_similarity)
    avg_similarity_score = sum(line_similarity)/blade_line

    return avg_similarity_score    

def reforge_imperfect_katana(imperfect_bp: str):
    '''
    Prompts the user to reshape the blade of the imperfect katana by entering
    the number of '#' symbols for each line. 
    
    Updates the imperfect blueprint with the new blade while keeping the handle
    intact, getting it as close as the perfect katana in perfect_katana.bp. 

    Parameters:
        imperfect_bp (str): The filename of the imperfect katana blueprint.
    '''
    print('>> REFORGING KATANA.\n')
    with open('perfect_katana.bp', 'r') as f1:
        perfect_max_width_count = 0
        perfect_hash_count = []
        for line in f1:
            if line.strip().startswith('#'):
                perfect_hash_count.append(line.count('#'))
            elif line.startswith('='):
                perfect_max_width_count = line.count('=') - 2
                break
        perfect_blade_size_count = len(perfect_hash_count)
            
    print('Katana Details:')    
    print(f'- Blade (lines): {perfect_blade_size_count}')
    print(f'- Maximum width: {perfect_max_width_count}\n')

    new_blade_lines = []
    i = 0 
    while i < perfect_blade_size_count:
        perfect_hash_count_input = '#' * perfect_hash_count[i]  
        katana_forge_line = input(f'Line ({i+1}/{perfect_blade_size_count}) [{perfect_hash_count_input}]: ')
        try:
            katana_forge_line_int = int(katana_forge_line)
            if 1 <= katana_forge_line_int <= perfect_max_width_count:
                new_blade_lines.append(' ' + '#' * katana_forge_line_int + '\n')
                i += 1
            else:
                print(f'Error: Input must be between 1 to {perfect_max_width_count} (inclusive).') 
        except ValueError:
            print("Error: Input must be an integer.")
    print("\n>> FORGING COMPLETE.")

    # with open(imperfect_bp, 'r') as f:
    #     handle_lines = []
    #     for line in f:
    #         if line.startswith('='):
    #             handle_lines.append(line)
    #         elif line.strip().startswith('|'):
    #             handle_lines.append(line)

    #create handle with seperator lines and handle lines
    handle_lines = []
    separator_line = "=" * (perfect_max_width_count + 2) + "\n"
    handle_lines.append(separator_line)
    
    handle_width = perfect_max_width_count
    handle_line = " " + "|" * handle_width + "\n"
    i = 0
    while i < 3: 
        handle_lines.append(handle_line)
        i += 1


    with open(imperfect_bp, 'w') as f:
        f.writelines(new_blade_lines)
        f.writelines(handle_lines)
        

    print_katana = input('Would you like to print the katana [yes/no]? ').strip().lower()
    if print_katana == 'yes':
        print('')
        for blade in new_blade_lines:
            print(blade, end = '')
        for handle in handle_lines:
            print(handle, end = '')


    return imperfect_bp


 
def main():
    '''
    Runs the full katana forging simulation from start to finish.

    Handles command line arguments, loads the blueprints, checks the
    similarity score, and repeatedly prompts the user to reforge the katana
    until it meets the required threshold.
    '''
    # 1. Process command-line arguments
    # - If an error occurs, print the message and exit
    if len(sys.argv) < 3:
        print('Error: Missing arguments.')
        print('Usage: python3 japan.py <imperfect_blueprint.bp> <min_similarity>')
        return
    imperfect_bp_file = sys.argv[1]
    try:
        threshold = float(sys.argv[2])
    except:
        print('Error: Invalid similarity score. Expected a float value.')
        return
    
    if not imperfect_bp_file.endswith('.bp'):
       print('Error: Invalid file extension. Expected a filename ending in .bp')
       return
    
    if not os.path.exists(imperfect_bp_file):
        print(f'Error: File not found. Please check that {imperfect_bp_file} exists.')
        return

    if threshold < 0 or threshold > 1: 
        print('Error: Similarity score must be between 0 and 1 (inclusive).')
        return

    print('>> READING IN BLUEPRINTS.\n')
    
    similarity_score = get_similarity_score(imperfect_bp_file)
    print('>> ANALYSING THEIR SIMILARITY.')
    print(f'Similarity score: {similarity_score:.2f}')

    while similarity_score < threshold:
        print('Denied: You must reforge it.\n')
        reforge_imperfect_katana(imperfect_bp_file)
        similarity_score = get_similarity_score(imperfect_bp_file)
        print('\n>> ANALYSING THEIR SIMILARITY.')
        print(f'Similarity score: {similarity_score:.2f}')
    print('Accepted: The blacksmith is satisfied.')
    return


    # 2. Initial similarity check
    # - If score meets or exceeds threshold, accept immediately

    # 3. Reforge loop
    # - Reforge and recheck similarity until accepted

    # print_katana('perfect_katana.bp')
    # get_similarity_score('my_katana.bp')

# Do not modify this!
if __name__ == '__main__':
    main()
