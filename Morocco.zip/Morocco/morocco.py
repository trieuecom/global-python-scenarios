'''
morocco.py

This program simulates a modern twist on the Moroccan spice trade.

Your task is to determine the cheapest order to purchase nine different 
spices such that the total cost does not exceed a given budget.

Prices are dynamic, depending on:
- The previously purchased spice.
- The last digit of your student ID.

Each spice's base price are defined in the SPICE_PRICES dictionary at the 
top of the file.
'''


SPICE_PRICES = {
    'Saffron': 12,
    'Cumin': 8,
    'Cinnamon': 10,
    'Coriander':7,
    'Turmeric':6,
    'Paprika':9,
    'Clove':11,
    'Ginger':7,
    'Star Anise':8
}  # fill in with base prices for each spice!


def is_valid_sid(sid: str) -> bool:
    '''
    Checks whether the provided student ID (SID) is valid.

    A valid SID must:
    - Be numeric.
    - Contain exactly 9 characters.

    Parameters:
        sid (str): The student ID to validate.

    Returns:
        bool: True if the SID is valid, False otherwise.
    '''
    if len(sid) == 9 and sid.isnumeric():
        return True
    else:
        return False

def calculate_spice_price(current_spice: str, previous_spice: str, sid_last_digit: int) -> float:
    '''
    Calculates the final price of a spice based on the previous spice's price
    and the last digit of the student ID.

    Formula:
        Final Price = Current Spice Base Price +
            Previous Spice Base Price * (SID + 1)^1.3 * 
            (1 + 0.07 * (Index of Current Spice % 3))

    Parameters:
        previous_spice (str): The name of the previously purchased spice.
        sid_last_digit (int): The last digit of the student ID (0-9).

    Returns:
        float: The final calculated price of the current spice.
    '''
    base_current_spice = SPICE_PRICES[current_spice]
    base_previous_spice = SPICE_PRICES[previous_spice]
    spice_list = list(SPICE_PRICES.keys())
    index_current_spice = spice_list.index(current_spice)
    final_price = base_current_spice + base_previous_spice * 
    pow((sid_last_digit +1),1.3) * (1 + 0.07 * (index_current_spice % 3))

    return final_price


def calculate_total_order_price(order: list[str], sid_last_digit: int) -> float:
    '''
    Calculates the total cost of purchasing a complete order of spices.

    The price of each spice is calculated based on its position in the order:
    - The first spice uses its base price.
    - All others use calculate_spice_price() with the previously purchased spice.

    Parameters:
        order (list[str]): The list of spices in purchase order.
        sid_last_digit (int): The last digit of the student ID (0-9).

    Returns:
        float: The total cost of the entire spice order.
    '''
    total_spice_order = 0.0
    for i in range(len(order)):
        if i == 0:
            current_price_spice = SPICE_PRICES[order[i]]
            total_spice_order += current_price_spice
        elif i > 0:
            current_spice = order[i]
            previous_spice = order[i-1]
            adjusted_price = calculate_spice_price(current_spice, previous_spice, sid_last_digit)
            total_spice_order += adjusted_price
   
    return total_spice_order


def purchase_spices(spices: list[str], sid_last_digit: int, budget: int, order: list[str]) -> list[str]:
    '''
    Recursively explores every order to purchase spices and return the one with the 
    lowest cost that fits within the given budget.

    Partial marks are awarded if its able to return a valid order that isn't the
    cheapest but still fits within budget.

    Parameters:
        spices (list[str]): A list of spices left to purchase.
        sid_last_digit (int): The last digit of the student ID.
        budget (int): The final purchase order's price must not exceed this value.
        order (list[str]): A list of spices that have already been purchased.

    Returns:
        list[str]: The order of spices, or empty list if none is possible.

    Note: 
        When this function is first called, spices will contain all 9 spices, 
        and order will be an empty list.
    '''
    if spices == []:
        total_cost = calculate_total_order_price(order, sid_last_digit)
        if total_cost <= budget: 
            return order
        else:
            return []
    
    best_order = []
    best_cost = float('inf')
    for spice in spices:
        new_order = order.copy()
        new_order.append(spice)

        new_spices = spices.copy()
        new_spices.remove(spice)

        result = purchase_spices(new_spices, sid_last_digit, budget, new_order)

        if result != []:
            cost = calculate_total_order_price(result, sid_last_digit)
            if cost < best_cost:
                best_cost = cost 
                best_order = result
    return best_order

        

def main():
    price = calculate_spice_price('Saffron', 'Paprika', 2)
    print(calculate_total_order_price(['Paprika', 'Cinnamon', 'Saffron'], 2))
    

if __name__ == '__main__':
    main()
