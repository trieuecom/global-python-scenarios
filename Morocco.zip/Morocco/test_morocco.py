'''
test_morocco.py

This file will contain your test cases for the morocco.py program.

TODO: Write instructions here on how to run this test file and interpret the 
results.
'''

import morocco
assert morocco.is_valid_sid('123456789') == True
print("Test case 1 pass")
assert morocco.is_valid_sid('098765432') == True
print("Test case 2 pass")
assert morocco.is_valid_sid('1234567') == False
print("Test case 3 pass")
assert morocco.is_valid_sid('0x3458922') == False
print("Test case 4 pass")
assert morocco.is_valid_sid(' 123456789 ') == False
print("Test case 5 pass")

 

