# Test Case Designs
Complete the given tables with the details of your test case design for the is_valid_sid function. 
For each test case, provide the following:

Column descriptions:
* Test ID - Test case identification number
* Description - Type of testcase and brief explanation of test case details
* Inputs - Argument into the method
* Expected Output - Return values of the method
* Status - pass/fail 

Note: You can resize the tables to your own liking.

Table 1: Positive test cases for `is_valid_sid`

| Test ID | Description                 | Inputs     | Expected Output | Status |
| ------- | --------------------------- | ------     | --------------- | ------ |
|    1    | Case with 9 nums and digits |'123456789' |      True       | Pass   |       
|    2    | Case with 9 nums and digits |'098765432' |      True       | Pass   |
|         |                             |            |                 |        |

Table 2: Negative cases for `is_valid_sid`

| Test ID | Description                 | Inputs     | Expected Output | Status |
| ------- | --------------------------- | ------     | --------------- | ------ |
|    3    | Case with length of sid < 9 |'1234567'   |      False      | Pass   |       
|    4    | Case with sid have a char   |'0x3458922' |      False      | Pass   |
|         |                             |            |                 |        |

Table 3: Edge test cases for `is_valid_sid`

| Test ID | Description                 | Inputs       | Expected Output | Status |
| ------- | --------------------------- | ------       | --------------- | ------ |
|    5    | Case with a empty string    |' 123456789 ' |      False      | Pass   |       
|         |                             |              |                 |        |
|         |                             |              |                 |        |
